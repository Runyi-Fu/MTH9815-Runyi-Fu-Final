/**
 * soa.hpp
 * Header file for defining foundational components of a Service-Oriented Architecture (SOA)
 *
 * Created by: Runyi Fu
 */
#ifndef SOA_HPP
#define SOA_HPP

#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
#include <map>
#include <unordered_map>
#include "products.hpp"
#include "utilityfunctions.hpp"

using namespace std;

/**
 * Abstract base class to define listeners for service events.
 * ServiceListener handles three types of events: add, update, and remove.
 * Listeners are attached to a Service to enable event-driven interactions.
 */
template<typename V>
class ServiceListener
{

public:

    // Callback for handling data addition to the Service
    virtual void ProcessAdd(V& _data) = 0;

    // Callback for handling data removal from the Service
    virtual void ProcessRemove(V& _data) = 0;

    // Callback for handling updates to the data in the Service
    virtual void ProcessUpdate(V& _data) = 0;

};

/**
 * Abstract base class representing a generic Service.
 * Uses template types K for keys and V for values.
 */
template<typename K, typename V>
class Service
{

public:

    // Retrieve data associated with a specific key
    virtual V& GetData(K _key) = 0;

    // Method invoked by a Connector to deliver new or updated data
    virtual void OnMessage(V& _data) = 0;

    // Attach a listener to monitor and respond to service events
    virtual void AddListener(ServiceListener<V>* _listener) = 0;

    // Retrieve all registered listeners for this Service
    virtual const vector<ServiceListener<V>*>& GetListeners() const = 0;

};

/**
 * Connector class that bridges data flow between a data source and a Service.
 * For subscriber Connectors, invokes Service.OnMessage() to send data to the Service.
 * For publisher Connectors, allows Services to push data to external systems.
 * A Connector can function as a publisher, subscriber, or both.
 */
template<typename V>
class Connector
{

public:

    // Send data from the Service to an external system
    virtual void Publish(V& _data) = 0;

    // Receive data from an external source and push it to the Service
    virtual void Subscribe(ifstream& _data) = 0;
};

#endif
