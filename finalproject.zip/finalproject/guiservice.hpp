/**
 * guiservice.hpp
 * Defines components and service for GUI data output.
 *
 * Created by: Runyi Fu
 */
#ifndef GUI_SERVICE_HPP
#define GUI_SERVICE_HPP

#include "soa.hpp"
#include "pricingservice.hpp"

/**
 * Forward declarations to resolve dependencies.
 */
template<typename T>
class GUIConnector;
template<typename T>
class GUIToPricingListener;

/**
 * Service for managing GUI updates with rate limiting (throttling).
 * The key is the product identifier.
 * Template parameter T represents the product type.
 */
template<typename T>
class GUIService : Service<string, Price<T>>
{

private:

	map<string, Price<T>> guis; // Stores data for GUI output
	vector<ServiceListener<Price<T>>*> listeners; // Event listeners for the service
	GUIConnector<T>* connector; // Connector for publishing data
	ServiceListener<Price<T>>* listener; // Listener for receiving data
	int throttle; // Time interval for throttling updates
	long millisec; // Last recorded time in milliseconds

public:

	// Constructor and destructor
	GUIService();
	~GUIService();

	// Retrieve service data by key
	Price<T>& GetData(string _key);

	// Callback for new or updated data from a connector
	void OnMessage(Price<T>& _data);

	// Register an event listener for the service
	void AddListener(ServiceListener<Price<T>>* _listener);

	// Retrieve all registered listeners
	const vector<ServiceListener<Price<T>>*>& GetListeners() const;

	// Access the connector associated with this service
	GUIConnector<T>* GetConnector();

	// Access the listener associated with this service
	ServiceListener<Price<T>>* GetListener();

	// Get the throttling interval for GUI updates
	int GetThrottle() const;

	// Get the current time in milliseconds
	long GetMillisec() const;

	// Set the current time in milliseconds
	void SetMillisec(long _millisec);

};

template<typename T>
GUIService<T>::GUIService()
{
	guis = map<string, Price<T>>();
	listeners = vector<ServiceListener<Price<T>>*>();
	connector = new GUIConnector<T>(this);
	listener = new GUIToPricingListener<T>(this);
	throttle = 300; // Default throttling interval
	millisec = 0;
}

template<typename T>
GUIService<T>::~GUIService() {}

template<typename T>
Price<T>& GUIService<T>::GetData(string _key)
{
	return guis[_key];
}

template<typename T>
void GUIService<T>::OnMessage(Price<T>& _data)
{
	guis[_data.GetProduct().GetProductId()] = _data;
	connector->Publish(_data);
}

template<typename T>
void GUIService<T>::AddListener(ServiceListener<Price<T>>* _listener)
{
	listeners.push_back(_listener);
}

template<typename T>
const vector<ServiceListener<Price<T>>*>& GUIService<T>::GetListeners() const
{
	return listeners;
}

template<typename T>
GUIConnector<T>* GUIService<T>::GetConnector()
{
	return connector;
}

template<typename T>
ServiceListener<Price<T>>* GUIService<T>::GetListener()
{
	return listener;
}

template<typename T>
int GUIService<T>::GetThrottle() const
{
	return throttle;
}

template<typename T>
long GUIService<T>::GetMillisec() const
{
	return millisec;
}

template<typename T>
void GUIService<T>::SetMillisec(long _millisec)
{
	millisec = _millisec;
}

/**
 * Connector responsible for publishing GUI data.
 * Template parameter T represents the product type.
 */
template<typename T>
class GUIConnector : public Connector<Price<T>>
{

private:

	GUIService<T>* service; // Pointer to the associated service

public:

	// Constructor and destructor
	GUIConnector(GUIService<T>* _service);
	~GUIConnector();

	// Publish data through the connector
	void Publish(Price<T>& _data);

	// Subscribe to data (not implemented here)
	void Subscribe(ifstream& _data);

};

template<typename T>
GUIConnector<T>::GUIConnector(GUIService<T>* _service)
{
	service = _service;
}

template<typename T>
GUIConnector<T>::~GUIConnector() {}

template<typename T>
void GUIConnector<T>::Publish(Price<T>& _data)
{
	int _throttle = service->GetThrottle();
	long _millisec = service->GetMillisec();
	long _millisecNow = GetMillisecond();
	while (_millisecNow < _millisec) _millisecNow += 1000;
	if (_millisecNow - _millisec >= _throttle)
	{
		service->SetMillisec(_millisecNow);
		ofstream _file;
		_file.open("gui.txt", ios::app);

		_file << TimeStamp() << ",";
		vector<string> _strings = _data.ToStrings();
		for (auto& s : _strings)
		{
			_file << s << ",";
		}
		_file << endl;
	}
}

template<typename T>
void GUIConnector<T>::Subscribe(ifstream& _data) {}

/**
 * Listener for receiving pricing data and forwarding it to the GUI service.
 * Template parameter T represents the product type.
 */
template<typename T>
class GUIToPricingListener : public ServiceListener<Price<T>>
{

private:

	GUIService<T>* service; // Pointer to the associated GUI service

public:

	// Constructor and destructor
	GUIToPricingListener(GUIService<T>* _service);
	~GUIToPricingListener();

	// Handle an add event for pricing data
	void ProcessAdd(Price<T>& _data);

	// Handle a remove event for pricing data (not implemented)
	void ProcessRemove(Price<T>& _data);

	// Handle an update event for pricing data (not implemented)
	void ProcessUpdate(Price<T>& _data);

};

template<typename T>
GUIToPricingListener<T>::GUIToPricingListener(GUIService<T>* _service)
{
	service = _service;
}

template<typename T>
GUIToPricingListener<T>::~GUIToPricingListener() {}

template<typename T>
void GUIToPricingListener<T>::ProcessAdd(Price<T>& _data)
{
	service->OnMessage(_data);
}

template<typename T>
void GUIToPricingListener<T>::ProcessRemove(Price<T>& _data) {}

template<typename T>
void GUIToPricingListener<T>::ProcessUpdate(Price<T>& _data) {}

#endif
