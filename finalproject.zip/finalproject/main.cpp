#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <memory>

// Include necessary headers
#include "soa.hpp"
#include "products.hpp"
#include "algoexecutionservice.hpp"
#include "algostreamingservice.hpp"
#include "executionservice.hpp"
#include "guiservice.hpp"
#include "historicaldataservice.hpp"
#include "inquiryservice.hpp"
#include "marketdataservice.hpp"
#include "positionservice.hpp"
#include "pricingservice.hpp"
#include "riskservice.hpp"
#include "streamingservice.hpp"
#include "tradebookingservice.hpp"

using namespace std;

// Function to initialize and return a service
template<typename Service>
shared_ptr<Service> InitializeService(const string& name)
{
    cout << "[INFO] Initializing " << name << "..." << endl;
    return make_shared<Service>();
}

// Main entry point of the program
int main()
{
    cout << "[INFO] Starting the bond trading system..." << endl;

    // Initialize services
    auto pricingService = InitializeService<PricingService<Bond>>("PricingService");
    auto tradeService = InitializeService<TradeBookingService<Bond>>("TradeBookingService");
    auto positionService = InitializeService<PositionService<Bond>>("PositionService");
    auto riskService = InitializeService<RiskService<Bond>>("RiskService");
    auto marketDataService = InitializeService<MarketDataService<Bond>>("MarketDataService");
    auto algoExecService = InitializeService<AlgoExecutionService<Bond>>("AlgoExecutionService");
    auto algoStreamService = InitializeService<AlgoStreamingService<Bond>>("AlgoStreamingService");
    auto guiService = InitializeService<GUIService<Bond>>("GUIService");
    auto execService = InitializeService<ExecutionService<Bond>>("ExecutionService");
    auto streamService = InitializeService<StreamingService<Bond>>("StreamingService");
    auto inquiryService = InitializeService<InquiryService<Bond>>("InquiryService");
    auto histPositionService = InitializeService<HistoricalDataService<Position<Bond>>>("HistoricalPositionService");
    auto histRiskService = InitializeService<HistoricalDataService<PV01<Bond>>>("HistoricalRiskService");
    auto histExecService = InitializeService<HistoricalDataService<ExecutionOrder<Bond>>>("HistoricalExecutionService");
    auto histStreamService = InitializeService<HistoricalDataService<PriceStream<Bond>>>("HistoricalStreamingService");
    auto histInquiryService = InitializeService<HistoricalDataService<Inquiry<Bond>>>("HistoricalInquiryService");

    cout << "[INFO] Linking services..." << endl;

    // Link services
    pricingService->AddListener(algoStreamService->GetListener());
    pricingService->AddListener(guiService->GetListener());
    algoStreamService->AddListener(streamService->GetListener());
    streamService->AddListener(histStreamService->GetListener());
    marketDataService->AddListener(algoExecService->GetListener());
    algoExecService->AddListener(execService->GetListener());
    execService->AddListener(tradeService->GetListener());
    execService->AddListener(histExecService->GetListener());
    tradeService->AddListener(positionService->GetListener());
    positionService->AddListener(riskService->GetListener());
    positionService->AddListener(histPositionService->GetListener());
    riskService->AddListener(histRiskService->GetListener());
    inquiryService->AddListener(histInquiryService->GetListener());

    cout << "[INFO] All services linked successfully." << endl;

    // Load data from files
    auto LoadData = [](const string& filename, auto& service) {
        cout << "[INFO] Processing data from " << filename << "..." << endl;
        ifstream file(filename);
        service->GetConnector()->Subscribe(file);
        cout << "[INFO] Data from " << filename << " processed successfully." << endl;
    };

    LoadData("prices.txt", pricingService);
    LoadData("trades.txt", tradeService);
    LoadData("marketdata.txt", marketDataService);
    LoadData("inquiries.txt", inquiryService);

    cout << "[INFO] Bond trading system shutting down..." << endl;
    cout << "[INFO] System terminated." << endl;

    cin.get(); // Wait for user input before exiting
    return 0;
}
