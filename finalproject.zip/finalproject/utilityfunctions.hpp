/**
* utilityfunctions.hpp
* Defines Utility functions for the trading system.
*
* Created by: Runyi Fu
*/
#ifndef UTILITY_FUNCTIONS_HPP
#define UTILITY_FUNCTIONS_HPP

#include <iostream>
#include <string>
#include <chrono>
#include "products.hpp"

using namespace std;
using namespace chrono;

// Generate uniformly distributed random variables between 0 to 1.
vector<double> GenerateUniform(long N, long seed = 0)
{
	const long m = 2147483647;
	const long a = 39373;

	if (seed == 0) seed = time(0); // Initialize seed if not provided
	seed = seed % m;

	vector<double> result;
	result.reserve(N); // Reserve memory to optimize push_back performance

	for (long i = 0; i < N; i++)
	{
		seed = (a * seed) % m; // Simplified LCG calculation
		result.push_back(static_cast<double>(seed) / m);
	}
	return result;
}


// Get Bond object for Treasury 2Y, 3Y, 5Y, 7Y, 10Y, 20Y and 30Y.
Bond GetBond(string _cusip)
{
	Bond _bond;
	if (_cusip == "912828ZQ6") _bond = Bond("912828ZQ6", CUSIP, "2Y", 0.04250, from_string("2026-11-30"));
	if (_cusip == "912828ZT0") _bond = Bond("912828ZT0", CUSIP, "3Y", 0.04000, from_string("2027-11-30"));
	if (_cusip == "912828ZW3") _bond = Bond("912828ZW3", CUSIP, "5Y", 0.04130, from_string("2029-11-30"));
	if (_cusip == "912828ZX1") _bond = Bond("912828ZX1", CUSIP, "7Y", 0.04130, from_string("2031-11-30"));
	if (_cusip == "912828ZY9") _bond = Bond("912828ZY9", CUSIP, "10Y", 0.04250, from_string("2034-11-30"));
	if (_cusip == "912810SR0") _bond = Bond("912810SR0", CUSIP, "20Y", 0.04630, from_string("2040-05-15"));
	if (_cusip == "912810TM0") _bond = Bond("912810TM0", CUSIP, "30Y", 0.04500, from_string("2054-11-15"));
	return _bond;
}

// Get PV01 value for US Treasury 2Y, 3Y, 5Y, 7Y, 10Y, 20Y and 30Y.
// not realistic values, but should be close.
double GetPV01Value(string _cusip)
{
	double _pv01 = 0;
	if (_cusip == "912828ZQ6") _pv01 = 0.019;
	if (_cusip == "912828ZT0") _pv01 = 0.028;
	if (_cusip == "912828ZW3") _pv01 = 0.045;
	if (_cusip == "912828ZX1") _pv01 = 0.060;
	if (_cusip == "912828ZY9") _pv01 = 0.075;
	if (_cusip == "912810SR0") _pv01 = 1.20;
	if (_cusip == "912810TM0") _pv01 = 1.50;	// Modified duration is estimated instrad of realistic.
	return _pv01;
}

// Convert fractional price to numerical price.
double ConvertPrice(string _stringPrice)
{
	string _stringPrice100 = "";
	string _stringPrice32 = "";
	string _stringPrice8 = "";

	int count = 0;
	for (int i = 0; i < _stringPrice.size(); i++)
	{
		if (_stringPrice[i] == '-')
		{
			count++;
			continue;
		}
		switch (count)
		{
		case 0:
			_stringPrice100.push_back(_stringPrice[i]);
			break;
		case 1:
			_stringPrice32.push_back(_stringPrice[i]);
			count++;
			break;
		case 2:
			_stringPrice32.push_back(_stringPrice[i]);
			count++;
			break;
		case 3:
			if (_stringPrice[i] == '+') _stringPrice[i] = '4';
			_stringPrice8.push_back(_stringPrice[i]);
			break;	
		}
	}

	double _doublePrice100 = stod(_stringPrice100);
	double _doublePrice32 = stod(_stringPrice32);
	double _doublePrice8 = stod(_stringPrice8);

	double _doublePrice = _doublePrice100 + _doublePrice32 * 1.0 / 32.0 + _doublePrice8 * 1.0 / 256.0;
	return _doublePrice;
}

// Convert numerical price to fractional price.
string ConvertPrice(double _doublePrice)
{
	int _doublePrice100 = floor(_doublePrice);
	int _doublePrice256 = floor((_doublePrice - _doublePrice100) * 256.0);
	int _doublePrice32 = floor(_doublePrice256 / 8.0);
	int _doublePrice8 = _doublePrice256 % 8;

	string _stringPrice100 = to_string(_doublePrice100);
	string _stringPrice32 = to_string(_doublePrice32);
	string _stringPrice8 = to_string(_doublePrice8);

	if (_doublePrice32 < 10) _stringPrice32 = "0" + _stringPrice32;
	if (_doublePrice8 == 4) _stringPrice8 = "+";

	string _stringPrice = _stringPrice100 + "-" + _stringPrice32 + _stringPrice8;
	return _stringPrice;
}

// Output Time Stamp with millisecond precision.
string TimeStamp()
{
	auto _timePoint = system_clock::now();
	auto _sec = chrono::time_point_cast<chrono::seconds>(_timePoint);
	auto _millisec = chrono::duration_cast<chrono::milliseconds>(_timePoint - _sec);

	auto _millisecCount = _millisec.count();
	string _milliString = to_string(_millisecCount);
	if (_millisecCount < 10) _milliString = "00" + _milliString;
	else if (_millisecCount < 100) _milliString = "0" + _milliString;

	time_t _timeT = system_clock::to_time_t(_timePoint);
	char _timeChar[24];
	strftime(_timeChar, 24, "%F %T", localtime(&_timeT));
	string _timeString = string(_timeChar) + "." + _milliString + " ";

	return _timeString;
}

// Get the millisecond count of current time.
long GetMillisecond()
{
	auto _timePoint = system_clock::now();
	auto _sec = chrono::time_point_cast<chrono::seconds>(_timePoint);
	auto _millisec = chrono::duration_cast<chrono::milliseconds>(_timePoint - _sec);
	long _millisecCount = _millisec.count();
	return _millisecCount;
}

// Generate random IDs.
string GenerateId()
{
	string _base = "1234567890QWERTYUIOPASDFGHJKLZXCVBNM";
	vector<double> _randoms = GenerateUniform(12, GetMillisecond());
	string _id = "";
	for (auto& r : _randoms)
	{
		int i = r * 36;
		_id.push_back(_base[i]);
	}
	return _id;
}

#endif
