/**
 * executionservice.hpp
 * Defines structures and services for handling executions.
 *
 * Created by: Runyi Fu
 */
#ifndef EXECUTION_SERVICE_HPP
#define EXECUTION_SERVICE_HPP

#include <string>
#include "soa.hpp"
#include "algoexecutionservice.hpp"

/**
 * Forward declarations to resolve dependencies.
 */
template<typename T>
class ExecutionToAlgoExecutionListener;

/**
 * Service for managing order executions on trading platforms.
 * Each order is associated with a product identifier.
 * Template parameter T specifies the product type.
 */
template<typename T>
class ExecutionService : public Service<string, ExecutionOrder<T>>
{

private:

	map<string, ExecutionOrder<T>> executionOrders; // Stores execution orders indexed by product ID
	vector<ServiceListener<ExecutionOrder<T>>*> listeners; // List of event listeners
	ExecutionToAlgoExecutionListener<T>* listener; // Listener for algo execution events

public:

	// Constructor and destructor
	ExecutionService();
	~ExecutionService();

	// Retrieves data for a given key
	ExecutionOrder<T>& GetData(string _key);

	// Callback invoked by connectors for incoming or updated data
	void OnMessage(ExecutionOrder<T>& _data);

	// Adds a listener for events in the service
	void AddListener(ServiceListener<ExecutionOrder<T>>* _listener);

	// Access all registered listeners
	const vector<ServiceListener<ExecutionOrder<T>>*>& GetListeners() const;

	// Retrieve the listener associated with this service
	ExecutionToAlgoExecutionListener<T>* GetListener();

	// Executes an order on the market
	void ExecuteOrder(ExecutionOrder<T>& _executionOrder);

};

// Constructor initializes storage and sets up the listener
template<typename T>
ExecutionService<T>::ExecutionService()
{
	executionOrders = map<string, ExecutionOrder<T>>();
	listeners = vector<ServiceListener<ExecutionOrder<T>>*>();
	listener = new ExecutionToAlgoExecutionListener<T>(this);
}

// Destructor cleans up resources
template<typename T>
ExecutionService<T>::~ExecutionService() {}

// Fetches execution data by its key
template<typename T>
ExecutionOrder<T>& ExecutionService<T>::GetData(string _key)
{
	return executionOrders[_key];
}

// Handles new or updated execution data
template<typename T>
void ExecutionService<T>::OnMessage(ExecutionOrder<T>& _data)
{
	executionOrders[_data.GetProduct().GetProductId()] = _data;
}

// Registers a new event listener for this service
template<typename T>
void ExecutionService<T>::AddListener(ServiceListener<ExecutionOrder<T>>* _listener)
{
	listeners.push_back(_listener);
}

// Returns all listeners monitoring this service
template<typename T>
const vector<ServiceListener<ExecutionOrder<T>>*>& ExecutionService<T>::GetListeners() const
{
	return listeners;
}

// Retrieves the specific listener tied to the algo execution
template<typename T>
ExecutionToAlgoExecutionListener<T>* ExecutionService<T>::GetListener()
{
	return listener;
}

// Executes the given order and notifies listeners
template<typename T>
void ExecutionService<T>::ExecuteOrder(ExecutionOrder<T>& _executionOrder)
{
	string _productId = _executionOrder.GetProduct().GetProductId();
	executionOrders[_productId] = _executionOrder;

	// Notify all registered listeners of the new order
	for (auto& l : listeners)
	{
		l->ProcessAdd(_executionOrder);
	}
}

/**
 * Listener for processing events from Algo Execution Service to Execution Service.
 * Template parameter T specifies the product type.
 */
template<typename T>
class ExecutionToAlgoExecutionListener : public ServiceListener<AlgoExecution<T>>
{

private:

	ExecutionService<T>* service; // Reference to the execution service

public:

	// Constructor and Destructor
	ExecutionToAlgoExecutionListener(ExecutionService<T>* _service);
	~ExecutionToAlgoExecutionListener();

	// Callback to process a new addition event
	void ProcessAdd(AlgoExecution<T>& _data);

	// Callback to process a removal event
	void ProcessRemove(AlgoExecution<T>& _data);

	// Callback to process an update event
	void ProcessUpdate(AlgoExecution<T>& _data);

};

// Constructor links the listener to the specified service
template<typename T>
ExecutionToAlgoExecutionListener<T>::ExecutionToAlgoExecutionListener(ExecutionService<T>* _service)
{
	service = _service;
}

// Destructor
template<typename T>
ExecutionToAlgoExecutionListener<T>::~ExecutionToAlgoExecutionListener() {}

// Processes a new algo execution and forwards it to the service
template<typename T>
void ExecutionToAlgoExecutionListener<T>::ProcessAdd(AlgoExecution<T>& _data)
{
	ExecutionOrder<T>* _executionOrder = _data.GetExecutionOrder();
	service->OnMessage(*_executionOrder); // Notify service of the new order
	service->ExecuteOrder(*_executionOrder); // Execute the order
}

// Process removal events (currently unimplemented)
template<typename T>
void ExecutionToAlgoExecutionListener<T>::ProcessRemove(AlgoExecution<T>& _data) {}

// Process update events (currently unimplemented)
template<typename T>
void ExecutionToAlgoExecutionListener<T>::ProcessUpdate(AlgoExecution<T>& _data) {}

#endif
